var main = function(){
    "use strict";


    $(".comment-input button").on("click",function (event) {
         console.log("Hola Mundo!");

    });
};
$(document).ready(main);